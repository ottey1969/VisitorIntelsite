
# Visitor Intel Platform Restoration Guide

## Quick Recovery Steps:

### 1. Set Up New Replit Project
- Create new Python Repl
- Upload all files from 'source_code' folder
- Copy 'configuration' files to root directory

### 2. Install Dependencies
```bash
# Install required packages
pip install flask flask-sqlalchemy anthropic openai google-genai requests psycopg2-binary gunicorn pillow pytz trafilatura
```

### 3. Set Environment Variables
- Copy values from 'environment_variables_template.json'
- Set your actual API keys in Replit Secrets:
  - OPENAI_API_KEY
  - ANTHROPIC_API_KEY
  - PERPLEXITY_API_KEY  
  - GEMINI_API_KEY
  - DATABASE_URL (PostgreSQL)
  - SESSION_SECRET

### 4. Restore Database
Option A (PostgreSQL):
```bash
psql $DATABASE_URL < database/postgresql_dump.sql
```

Option B (JSON Import):
- Run the platform once to create tables
- Use the database restoration script with 'complete_data.json'

### 5. Start the Platform
```bash
python main.py
```

## Files Included:
- ✅ Complete source code
- ✅ All templates and static files
- ✅ Database dump (JSON + SQL)
- ✅ Configuration files
- ✅ Asset files and images

## Critical Components Backed Up:
- 4-AI conversation system (OpenAI, Anthropic, Perplexity, Gemini)
- 24/7 keepalive system
- Payment processing
- Social media automation
- Infographic generation
- Geographic localization
- Admin dashboard
- Verification endpoints

## Support:
If restoration fails, check:
1. All environment variables are set correctly
2. Database connection is working
3. API keys are valid
4. Dependencies are installed

Your Visitor Intel platform will be fully operational after following these steps.
